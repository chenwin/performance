for i in `seq 5`;
do
  sh run.sh
done